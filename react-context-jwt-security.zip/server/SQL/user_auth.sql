-- Active: 1729210488806@@127.0.0.1@3306@membersdb

-- USER_AUTH : 권한 테이블

CREATE TABLE USER_AUTH(
	AUTH_NO INT NOT NULL auto_increment PRIMARY KEY,   -- 권한 번호
   USER_ID VARCHAR(100) NOT NULL,                     -- 아이디
   AUTH VARCHAR(100) NOT NULL                         -- 권한(USER, ADMIN)
);

-- 사용자 권한 : USER
INSERT INTO USER_AUTH(USER_ID, AUTH) VALUES('USER', 'ROLE_USER');

-- 관리자 권한 : USER, ADMIN
INSERT INTO USER_AUTH(USER_ID, AUTH) VALUES('ADMIN', 'ROLE_ADMIN');
INSERT INTO USER_AUTH(USER_ID, AUTH) VALUES('ADMIN', 'ROLE_USER');

SELECT * FROM user_auth;







DELETE FROM user_auth;